import json
import datetime
from pathlib import Path
from openaq import OpenAQ
from openaq.core.exceptions import APIError
import orjson
import calendar
import time

from src.common.config import settings
from src.common.logger import logger
from src.common.constants import (
    NYC_LATITUDE,
    NYC_LONGITUDE
)
from src.common.timer import timeit
from src.common.watermark import (
    read_watermark,
    write_watermark
)


class OpenAQBronzeClient:
    """API Client to ingest raw air quality payloads from OpenAQ."""

    def __init__(self, 
                 city_name: str = "nyc", 
                 coordinates: tuple[float, float] = (NYC_LATITUDE, NYC_LONGITUDE),
                 radius: int = 25_000,
                 target_parameters: set[str] | None = None
                ):
        if not settings.OPENAQ_API_KEY:
            logger.error("OpenAQ API Key missing in environment variables")
            raise ValueError("OPENAQ_API_KEY must be populated")

        self.city_slug = city_name.lower()
        self.coordinates = coordinates
        self.radius = radius
        self.target_parameters = target_parameters or {"pm25", "no2", "o3"}

        self.client = OpenAQ(api_key=settings.OPENAQ_API_KEY)
        self.target_dir = Path(settings.OPENAQ_RAW_TARGET_DIR)
        self.target_dir.mkdir(parents=True, exist_ok=True)
        self.watermark_path = self.target_dir / f"_openaq_{self.city_slug}_{settings.OPENAQ_WATERMARK_FILENAME}"


    def _call_with_retry(self, func, *args, max_retries: int = 3, **kwargs):
        """Executes an SDK call with exponential backoff for transient network errors."""
        for attempt in range(1, max_retries + 1):
            try:
                return func(*args, **kwargs)
            except Exception as err:
                if attempt == max_retries:
                    raise
                wait_time = 2 ** attempt
                logger.warning(
                    f"Transient API error (attempt {attempt}/{max_retries}): {err}. "
                    f"Retrying in {wait_time}s..."
                )
                time.sleep(wait_time)

    
    def _calculate_safe_end_month(self) -> datetime.date:
        """
        Calculates the first day of the last completed calendar month
        """

        today = datetime.date.today()
        first_of_this_month = today.replace(day=1)
        previous_month = first_of_this_month - datetime.timedelta(days=1)
        return previous_month.replace(day=1)


    @timeit
    def fetch_measurements_range(self, start_date: datetime.date, end_date: datetime.date) -> str:
        """
        Fetches a multi-day window air quality logs.
        """

        start_str = start_date.strftime("%Y-%m-%d")
        end_str = end_date.strftime("%Y-%m-%d")
        filename = f"openaq_{self.city_slug}_{start_str}_to_{end_str}.jsonl"
        output_path = self.target_dir / filename
        temp_path = self.target_dir / f"{filename}.tmp"

        if output_path.exists() and output_path.stat().st_size > 0:
            logger.info(f"File already cached locally: {filename}")
            return str(output_path)

        logger.info(f"Identifying active {self.city_slug.upper()} locations for window: {start_str} to {end_str}")

        if temp_path.exists():
            temp_path.unlink()
        
        try:
            locations_response = self._call_with_retry(
                self.client.locations.list,
                coordinates=self.coordinates,
                radius=self.radius,
                limit=100
            )
            
            locations = locations_response.results
            if not locations:
                logger.warning(f"No operational OpenAQ locations discovered near {self.city_slug.upper()} location.")
                return ""

            records_written = 0
            with open(temp_path, "wb") as f:
                for location in locations:
                    dt_first_str = getattr(getattr(location, "datetime_first", None), "utc", None)
                    if dt_first_str:
                        loc_first_date = datetime.date.fromisoformat(dt_first_str[:10])
                        if loc_first_date > end_date:
                            continue
                    
                    sensors_response = self._call_with_retry(self.client.locations.sensors, location.id)
                    sensors = sensors_response.results
                    
                    for sensor in sensors:
                        param_name = getattr(sensor.parameter, "name", "").lower()
                        if param_name not in self.target_parameters:
                            continue

                        logger.info(f"Pulling {param_name.upper()} from location {location.id} (Sensor {sensor.id})")
                        page = 1
                        limit = 1000
                        
                        while True:
                            measurements_response = self._call_with_retry(
                                self.client.measurements.list,
                                sensor.id,
                                "measurements",
                                datetime_from=start_str,
                                datetime_to=end_str,
                                limit=limit,
                                page=page
                            )
                            
                            measurements = measurements_response.results
                            if not measurements:
                                break
                            
                            batch_data = orjson.loads(measurements_response.json(encoder=orjson))
                            items = batch_data.get("results", []) if isinstance(batch_data, dict) else batch_data

                            lat = getattr(location.coordinates, "latitude", None) if location.coordinates else None
                            lon = getattr(location.coordinates, "longitude", None) if location.coordinates else None

                            for item in items:
                                item["_ingestion_meta"] = {
                                    "city": self.city_slug,
                                    "location_id": location.id,
                                    "location_name": location.name,
                                    "sensor_id": sensor.id,
                                    "latitude": lat,
                                    "longitude": lon,
                                }
                                f.write(orjson.dumps(item) + b"\n")
                                records_written += 1
                            
                            if len(measurements) < limit:
                                break
                            page += 1

            if records_written == 0:
                if temp_path.exists():
                    temp_path.unlink()
                logger.warning(f"No target pollutant measurements recorded between {start_str} and {end_str}.")
                return ""

            temp_path.replace(output_path)
            
            logger.info(f"Successfully landed raw bronze payload: {filename} ({records_written} records)")
            return str(output_path)

        except APIError as api_err:
            logger.error(f"OpenAQ API Exception encountered: {api_err}")
            return ""
        except Exception as err:
            if temp_path.exists():
                temp_path.unlink()
            logger.error(f"Ingestion aborted and rolled back staging file for {filename}: {err}")
            return ""

    def run_incremental_air_measurements_ingestion(self, fallback_year: int, fallback_month: int) -> None:
        """
        Automatically detects state context and incrementally syncs monthly 
        air quality batches up to the last completed calendar month.
        """

        latest_month = read_watermark(
            watermark_path=self.watermark_path, 
            key="last_ingested_date",
            date_format="%Y-%m"
            )
        end_month = self._calculate_safe_end_month()

        if latest_month:
            if latest_month == 12:
                current_month = datetime.date(latest_month.year + 1, 1, 1)
            else:
                current_month = datetime.date(latest_month.year, latest_month.month + 1, 1)
            logger.info(f"Found OpenAQ checkpoint. Last ingested month: {latest_month.strftime('%Y-%m')}")
        else:
            current_month = datetime.date(fallback_year, fallback_month, 1)
            logger.info(f"No OpenAQ watermark found. Cold starting from: {current_month.strftime('%Y-%m')}")

        if current_month > end_month:
            logger.info("OpenAQ data is completely up to date! No new months to ingest.")
            return

        while current_month <= end_month:
            _, last_day = calendar.monthrange(current_month.year, current_month.month)
            month_end_date = datetime.date(current_month.year, current_month.month, last_day)

            saved_path = self.fetch_measurements_range(current_month, month_end_date)
            if saved_path:
                write_watermark(
                    self.watermark_path,
                    current_month,
                    key="last_ingested_date",
                    date_format="%Y-%m"
                    )

            if current_month.month == 12:
                current_month = datetime.date(current_month.year + 1, 1, 1)
            else:
                current_month = datetime.date(current_month.year, current_month.month + 1, 1)


if __name__ == "__main__":
    import datetime
    ingest_worker = OpenAQBronzeClient("nyc", (NYC_LATITUDE, NYC_LONGITUDE), 25_000)
    ingest_worker.run_incremental_air_measurements_ingestion(fallback_year=2015, fallback_month=1)