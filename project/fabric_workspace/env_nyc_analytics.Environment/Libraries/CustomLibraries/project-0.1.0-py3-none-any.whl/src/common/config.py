import os
from dotenv import load_dotenv, find_dotenv


load_dotenv(find_dotenv())


class Config:
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "LOCAL")
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO").upper()
    LOG_FORMAT: str = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    LOG_DATE_FORMAT: str = "%Y-%m-%d %H:%M:%S"

    BRONZE_BASE_DIR: str = os.getenv("BRONZE_BASE_DIR", "data/raw")

    NYC_TAXI_BASE_URL: str = os.getenv("NYC_TAXI_BASE_URL", "https://cloudfront.net")
    NYC_FILE_PREFIX: str = os.getenv("NYC_FILE_PREFIX", "yellow_tripdata")
    FALLBACK_OLDEST_TAXI_DATA_DATE: int = 2009
    NYC_TAXI_RAW_TARGET_DIR: str = os.getenv("NYC_TAXI_RAW_TARGET_DIR", "data/raw/taxi")
    NYC_WATERMARK_FILENAME: str = os.getenv("NYC_WATERMARK_FILENAME", "_watermark.json")
    SILVER_TAXI_TABLE: str = os.getenv("SILVER_TAXI_TABLE", "silver_taxi_trips")

    OPENAQ_API_URL: str = os.getenv("OPENAQ_API_URL", "https://openaq.org")
    OPENAQ_API_KEY: str = os.getenv("OPENAQ_API_KEY", "")
    OPENAQ_RAW_TARGET_DIR = os.getenv("OPENAQ_RAW_TARGET_DIR", "data/raw/air_quality")
    OPENAQ_WATERMARK_FILENAME: str = os.getenv("NYC_WATERMARK_FILENAME", "_watermark.json")
    SILVER_AIR_QUALITY_TABLE: str = os.getenv("SILVER_AIR_QUALITY_TABLE", "silver_air_quality")
    
    WORLDBANK_API_URL: str = os.getenv("WORLDBANK_API_URL", "https://worldbank.org")
    WORLDBANK_RAW_TARGET_DIR: str = os.getenv("WORLDBANK_RAW_TARGET_DIR", "data/raw/worldbank")
    WORLDBANK_WATERMARK_FILENAME: str = os.getenv("WORLDBANK_WATERMARK_FILENAME", "_watermark.json")

    ECB_FX_URL: str = os.getenv("ECB_FX_URL", "https://europa.eu")
    ECB_FX_RAW_TARGET_DIR: str = os.getenv("ECB_FX_RAW_TARGET_DIR", "data/raw/ecb_fx")
    ECB_FX_WATERMARK_FILENAME: str = os.getenv("ECB_FX_WATERMARK_FILENAME", "_watermark.json")

    SILVER_MACRO_TABLE: str = os.getenv("SILVER_MACRO_TABLE", "silver_macro_economic")
    SILVER_WATERMARKS_PATH: str = os.getenv("SILVER_WATERMARKS_PATH", "data/silver/watermarks")

    GOLD_DIM_DATE_TABLE: str = os.getenv("GOLD_DIM_DATE_TABLE", "gold_dim_date")
    GOLD_DIM_MACRO_TABLE: str = os.getenv("GOLD_DIM_MACRO_TABLE", "gold_dim_macro")
    GOLD_DIM_LOCATION_TABLE: str = os.getenv("GOLD_DIM_LOCATION_TABLE", "gold_dim_location")
    GOLD_FACT_MOBILITY_ENV_TABLE: str = os.getenv("GOLD_FACT_MOBILITY_ENV_TABLE", "gold_fact_mobility_env")


settings = Config()